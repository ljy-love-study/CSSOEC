## Challenges


<div align="left">
  <img src="https://insightface.ai/assets/img/custom/logo3.jpg" width="240"/>
</div>


## Introduction

These benchmarks are maintained by [InsightFace](https://insightface.ai)


<div align="left">
  <img src="https://insightface.ai/assets/img/custom/thumb_ifrt.png" width="480"/>
</div>



## Supported Benchmarks
- [MFR-Ongoing](mfr) (Ongoing version of iccv21-mfr)
- [MFR21 (ICCVW'2021)](iccv21-mfr)
- [LFR19 (ICCVW'2019)](iccv19-lfr)






