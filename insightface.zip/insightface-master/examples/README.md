InsightFace Example
---

Before running the examples, please install insightface package via `pip install -U insightface`
