## Face Attribute


<div align="left">
  <img src="https://insightface.ai/assets/img/custom/logo3.jpg" width="320"/>
</div>


## Introduction

These are the face attribute methods of [InsightFace](https://insightface.ai)


<div align="left">
  <img src="https://insightface.ai/assets/img/github/t1_genderage.jpg" width="600"/>
</div>



## Methods


Supported methods:

- [x] [Gender_Age](gender_age)



## Contributing

We appreciate all contributions to improve the face attribute module of InsightFace. 


