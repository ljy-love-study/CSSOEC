# Face Detection Datasets

(Updating)

## Training Datasets

### WiderFace

http://shuoyang1213.me/WIDERFACE/



## Test Datasets

### WiderFace

http://shuoyang1213.me/WIDERFACE/

### FDDB

http://vis-www.cs.umass.edu/fddb/

### AFW


### PASCAL FACE


### MALF

http://www.cbsr.ia.ac.cn/faceevaluation/
